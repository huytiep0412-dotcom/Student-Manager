<?php
function sm_student_list_shortcode() {
    $args = array(
        'post_type' => 'sinh_vien',
        'posts_per_page' => -1,
        'status' => 'publish'
    );
    $query = new WP_Query($args);

    if ($query->have_posts()) {
        $output = '<table border="1" style="width:100%; border-collapse: collapse; text-align: left;">';
        $output .= '<thead><tr><th>STT</th><th>MSSV</th><th>Họ tên</th><th>Lớp</th><th>Ngày sinh</th></tr></thead><tbody>';
        
        $stt = 1;
        while ($query->have_posts()) {
            $query->the_post();
            $id = get_the_ID();
            $mssv = get_post_meta($id, '_sm_mssv', true);
            $lop = get_post_meta($id, '_sm_lop', true);
            $ngay_sinh = get_post_meta($id, '_sm_ngay_sinh', true);

            $output .= "<tr>
                <td>{$stt}</td>
                <td>" . esc_html($mssv) . "</td>
                <td>" . get_the_title() . "</td>
                <td>" . esc_html($lop) . "</td>
                <td>" . esc_html($ngay_sinh) . "</td>
            </tr>";
            $stt++;
        }
        $output .= '</tbody></table>';
        wp_reset_postdata();
        return $output;
    }
    return 'Chưa có sinh viên nào.';
}
add_shortcode('danh_sach_sinh_vien', 'sm_student_list_shortcode');