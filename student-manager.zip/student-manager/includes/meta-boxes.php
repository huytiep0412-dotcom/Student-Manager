<?php
// Thêm Meta Box vào trang soạn thảo
function sm_add_student_meta_boxes() {
    add_meta_box('sm_student_details', 'Thông tin chi tiết sinh viên', 'sm_student_meta_box_html', 'sinh_vien', 'normal', 'high');
}
add_action('add_meta_boxes', 'sm_add_student_meta_boxes');

// HTML hiển thị các trường nhập liệu
function sm_student_meta_box_html($post) {
    $mssv = get_post_meta($post->ID, '_sm_mssv', true);
    $lop = get_post_meta($post->ID, '_sm_lop', true);
    $ngay_sinh = get_post_meta($post->ID, '_sm_ngay_sinh', true);

    wp_nonce_field('sm_save_student_data', 'sm_student_nonce');
    ?>
    <p>
        <label>Mã số sinh viên (MSSV):</label><br>
        <input type="text" name="sm_mssv" value="<?php echo esc_attr($mssv); ?>" style="width:100%">
    </p>
    <p>
        <label>Lớp/Chuyên ngành:</label><br>
        <select name="sm_lop" style="width:100%">
            <option value="CNTT" <?php selected($lop, 'CNTT'); ?>>CNTT</option>
            <option value="Kinh tế" <?php selected($lop, 'Kinh tế'); ?>>Kinh tế</option>
            <option value="Marketing" <?php selected($lop, 'Marketing'); ?>>Marketing</option>
        </select>
    </p>
    <p>
        <label>Ngày sinh:</label><br>
        <input type="date" name="sm_ngay_sinh" value="<?php echo esc_attr($ngay_sinh); ?>" style="width:100%">
    </p>
    <?php
}

// Lưu dữ liệu (Xử lý Nonce và Sanitize)
function sm_save_student_meta($post_id) {
    if (!isset($_POST['sm_student_nonce']) || !wp_verify_nonce($_POST['sm_student_nonce'], 'sm_save_student_data')) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;

    if (isset($_POST['sm_mssv'])) update_post_meta($post_id, '_sm_mssv', sanitize_text_field($_POST['sm_mssv']));
    if (isset($_POST['sm_lop'])) update_post_meta($post_id, '_sm_lop', sanitize_text_field($_POST['sm_lop']));
    if (isset($_POST['sm_ngay_sinh'])) update_post_meta($post_id, '_sm_ngay_sinh', sanitize_text_field($_POST['sm_ngay_sinh']));
}
add_action('save_post', 'sm_save_student_meta');