<?php
function sm_register_student_cpt() {
    $labels = array(
        'name' => 'Sinh viên',
        'singular_name' => 'Sinh viên',
        'add_new' => 'Thêm sinh viên mới',
        'add_new_item' => 'Thêm sinh viên',
        'edit_item' => 'Sửa thông tin sinh viên',
        'all_items' => 'Tất cả sinh viên',
    );

    $args = array(
        'labels' => $labels,
        'public' => true,
        'has_archive' => true,
        'menu_icon' => 'dashicons-id-alt', // Icon thẻ ID
        'supports' => array('title', 'editor'), // Họ tên và Tiểu sử
        'rewrite' => array('slug' => 'sinh-vien'),
    );

    register_post_type('sinh_vien', $args);
}
add_action('init', 'sm_register_student_cpt');