<?php
/**
 * Plugin Name: Student Manager
 * Description: Quản lý sinh viên với Custom Post Type và Meta Boxes.
 * Version: 1.0
 * Author: [Tên của bạn]
 */

if (!defined('ABSPATH')) exit;

// Định nghĩa đường dẫn
define('SM_PATH', plugin_dir_path(__FILE__));

// Nhúng các file xử lý logic
require_once SM_PATH . 'includes/cpt-sinh-vien.php';
require_once SM_PATH . 'includes/meta-boxes.php';
require_once SM_PATH . 'includes/shortcode.php';